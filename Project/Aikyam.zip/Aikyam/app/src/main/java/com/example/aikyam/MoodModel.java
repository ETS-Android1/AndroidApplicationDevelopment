package com.example.aikyam;

public class MoodModel {

    String date;
    String mood;
    String description;
}


